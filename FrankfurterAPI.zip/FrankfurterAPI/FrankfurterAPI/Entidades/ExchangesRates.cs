﻿using Microsoft.VisualBasic;
using System.ComponentModel.DataAnnotations;

namespace FrankfurterAPI.Entidades
{
    public class ExchangesRates
    {
        public int Id { get; set; }
        [StringLength(3)]
        public string BaseCurrency { get; set; } = null!;
        [StringLength(3)]
        public string TargetCurrency { get; set; } = null!;
        public decimal Rate { get; set; }
        public DateTime Date { get; set; }
    }
}
