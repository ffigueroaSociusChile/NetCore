﻿using System.ComponentModel.DataAnnotations;

namespace FrankfurterAPI.Entidades
{
    public class Currency
    {
        public int Id { get; set; }
        [StringLength(3)]
        public string NameSymbol { get; set; } = null!;
        [StringLength(50)]
        public string Name { get; set; } = null!;
    }
}
