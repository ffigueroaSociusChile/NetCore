﻿using AutoMapper;
using FluentValidation;
using FrankfurterAPI.DTOs;
using FrankfurterAPI.Entidades;
using FrankfurterAPI.Repositorios;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.IdentityModel.Protocols.Configuration;
using System.Net.Http;
using System.Text.Json;

namespace FrankfurterAPI.EndPoints
{
    public static class RatesEndpoint
    {
        public static RouteGroupBuilder MapRatesGroup(this RouteGroupBuilder routeGroup)
        {
            routeGroup.MapGet("/", ListadoDeCurrency)
    .CacheOutput(t => t.Expire(TimeSpan.FromSeconds(15)).Tag("currency-tag")).RequireAuthorization();

            routeGroup.MapGet("/{id:int}", ListarCurrency).RequireAuthorization();
            
            routeGroup.MapPut("/{id:int}", ActualizarCurrency).RequireAuthorization();


            routeGroup.MapPost("/", CrearCurrency).RequireAuthorization();

            routeGroup.MapDelete("/{id:int}", EliminarCurrency).RequireAuthorization();


            routeGroup.MapGet("/currency/{baseCurrency:alpha}", TasasDeCambio).RequireAuthorization();

            routeGroup.MapGet("/listarCurrencies", ListasCurrencies).RequireAuthorization();

            return routeGroup;
        }


        static async Task<Ok<List<CurrencyDto>>> ListadoDeCurrency(IRepositorioCurrency repositorioCurrency, IMapper mapper)
        {
            var listCurrency = await repositorioCurrency.ListadoDeCurrency();
            var currencyDto = mapper.Map<List<CurrencyDto>>(listCurrency);
            return TypedResults.Ok(currencyDto);
        }

        static async Task<Results<Ok<CurrencyDto>, NotFound>> ListarCurrency(IRepositorioCurrency repositorioCurrency, int Id, IMapper mapper)
        {
            var currency = await repositorioCurrency.ListarCurrency(Id);
            if (currency is null)
            {
                return TypedResults.NotFound();
            }

            var currencyDto = mapper.Map<CurrencyDto>(currency);
            return TypedResults.Ok(currencyDto);
        }

        static async Task<Results<NoContent, NotFound, ValidationProblem>> ActualizarCurrency(
            int id,
            ActualizaCurrencyDto actualizaCurrencyDto,
            IRepositorioCurrency repositorioCurrency,
            IOutputCacheStore outputCacheStore,
            IMapper mapper,
            IValidator<ActualizaCurrencyDto> validador
            )
        {
            var resultadosValidador = await validador.ValidateAsync(actualizaCurrencyDto);

            if (!resultadosValidador.IsValid)
            {
                return TypedResults.ValidationProblem(resultadosValidador.ToDictionary());
            }

            var currency = mapper.Map<Currency>(actualizaCurrencyDto);

            var existe = await repositorioCurrency.Existe(currency.NameSymbol);

            currency.Id = id;
            await repositorioCurrency.ActualizarCurrency(currency);
            await outputCacheStore.EvictByTagAsync("currency-tag", default);
            return TypedResults.NoContent();

        }

        static async Task<Results<Created<CurrencyDto>, NotFound, ValidationProblem>> CrearCurrency(
            CrearCurrencyDto crearCurrencyDto, 
            IRepositorioCurrency repositorioCurrency, 
            IOutputCacheStore outputCacheStore,
            IMapper mapper,
            IValidator<CrearCurrencyDto> validador
            )
        {

            var resultadosValidador = await validador.ValidateAsync(crearCurrencyDto);

            if (!resultadosValidador.IsValid)
            {
                return TypedResults.ValidationProblem(resultadosValidador.ToDictionary());
            }
            var currency = mapper.Map<Currency>(crearCurrencyDto);

            var id = await repositorioCurrency.Crear(currency);
            await outputCacheStore.EvictByTagAsync("currency-tag", default);
            var currencyDto = mapper.Map<CurrencyDto>(currency);
            return TypedResults.Created($"/crearCurrency/{id}", currencyDto);
        }

        static async Task<Results<NoContent, NotFound>> EliminarCurrency(
            int id, 
            IRepositorioCurrency repositorioCurrency, IOutputCacheStore outputCacheStore)
        {
            var existeId = await repositorioCurrency.ExisteId(id);
            if (!existeId)
            {
                return TypedResults.NotFound();
            }

            await repositorioCurrency.BorrarCurrency(id);
            await outputCacheStore.EvictByTagAsync("currency-tag", default);
            return TypedResults.NoContent();
        }

        static async Task<Results<Ok<List<CrearCurrencyDto>>, NotFound>> ListasCurrencies(
            HttpClient httpClient, 
            IRepositorioCurrency repositorioCurrency, 
            IMapper mapper,
            IOutputCacheStore outputCacheStore)
        {
            var url = $"https://api.frankfurter.app/currencies";
            var response = await httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var currencyData = JsonSerializer.Deserialize<Dictionary<string, string>>(content)!;

                var curriencies = currencyData.Select(kv => new CrearCurrencyDto
                {
                    nameSymbol = kv.Key,
                    name = kv.Value,
                }
                    ).ToList();

                var listCurrencyDto = mapper.Map<List<CrearCurrencyDto>>(curriencies);

                return TypedResults.Ok(listCurrencyDto);
            }
            return TypedResults.NotFound();
        }

        static async Task<Results<Ok<LatestResponseDto>, NotFound>> TasasDeCambio(HttpClient httpClient, string baseCurrency)
        {
            var url = $"https://api.frankfurter.app/latest?from={baseCurrency}";
            var response = await httpClient.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var currencyData = JsonSerializer.Deserialize<LatestResponseDto>(content);
                return TypedResults.Ok(currencyData);
            }
            return TypedResults.NotFound();
        }

    }
}
