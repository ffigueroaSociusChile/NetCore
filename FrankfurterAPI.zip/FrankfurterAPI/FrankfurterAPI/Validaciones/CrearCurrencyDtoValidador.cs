﻿using FluentValidation;
using FrankfurterAPI.DTOs;
using FrankfurterAPI.Repositorios;
using FrankfurterAPI.Utilidades;

namespace FrankfurterAPI.Validaciones
{
    public class CrearCurrencyDtoValidador : AbstractValidator<CrearCurrencyDto>
    {
        public CrearCurrencyDtoValidador(IRepositorioCurrency repositorioCurrency) 
        {
            RuleFor(x => x.name).NotEmpty().WithMessage(baseErrores.CampoRequerido)
                .MaximumLength(50).WithMessage(baseErrores.MaximoCampoRequerido)
                .MustAsync(async (name, _) =>
                {
                    var existeName = await repositorioCurrency.ExisteName(name);
                    return !existeName;
                }).WithMessage(g => $"ya existe un currency con ese nombre {g.name}");

            RuleFor(x => x.nameSymbol).NotEmpty().WithMessage(baseErrores.CampoRequerido)
                .MaximumLength(3).WithMessage(baseErrores.MaximoCampoRequerido)                
                .MustAsync(async (symbol, _) =>
                {
                    var existe = await repositorioCurrency.Existe(symbol);
                    return !existe;
                }).WithMessage(g => $"ya existe un symbol con ese nombre {g.nameSymbol}");
        }
    }
}
