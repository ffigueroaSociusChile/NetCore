using FluentValidation;
using FrankfurterAPI;
using FrankfurterAPI.EndPoints;
using FrankfurterAPI.Entidades;
using FrankfurterAPI.Repositorios;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;


var builder = WebApplication.CreateBuilder(args);
var url = builder.Configuration.GetValue<string>("urlFranckfurter");

//ini services
builder.Services.AddDbContext<ApplicationDbContext>(opc =>
    opc.UseSqlServer("name=DefaultConnection")
);

builder.Services.AddCors(parametros =>
        parametros.AddDefaultPolicy(config =>
            {
                config.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
            })
    );

builder.Services.AddOutputCache();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<IRepositorioCurrency, RepositorioCurrency>();

builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddValidatorsFromAssemblyContaining<Program>();

builder.Services.AddHttpClient();

builder.Services.AddAuthentication().AddJwtBearer();
builder.Services.AddAuthorization();


//end Services
var app = builder.Build();

//ini middleware
app.UseSwagger();
app.UseSwaggerUI();

app.UseCors();
app.UseOutputCache();
app.UseHttpsRedirection();
app.UseAuthorization();

app.MapGroup("/rates").MapRatesGroup();

//end middelware

app.Run();
