﻿using AutoMapper;
using FrankfurterAPI.DTOs;
using FrankfurterAPI.Entidades;

namespace FrankfurterAPI.Utilidades
{
    public class AutoMapperProfiles: Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<CrearCurrencyDto,Currency>();
            CreateMap<Currency, CurrencyDto>();
            CreateMap<ActualizaCurrencyDto,Currency>();
        }
    }
}
