﻿namespace FrankfurterAPI.Utilidades
{
    public static class baseErrores
    {
        public static String CampoRequerido = "El campo {PropertyName} es requerido.";
        public static String MaximoCampoRequerido = "El campo {PropertyName} tiene un maximo de {MaxLength} caracteres.";
    }
}
