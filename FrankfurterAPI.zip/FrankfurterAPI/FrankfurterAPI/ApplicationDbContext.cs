﻿using FrankfurterAPI.Entidades;
using Microsoft.EntityFrameworkCore;

namespace FrankfurterAPI
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Currency> Currency { get; set; }
        public DbSet<ExchangesRates> ExchangesRates { get; set; }

    }
}
