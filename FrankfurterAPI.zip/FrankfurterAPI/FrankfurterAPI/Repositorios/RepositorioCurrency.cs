﻿using FrankfurterAPI.Entidades;
using Microsoft.EntityFrameworkCore;

namespace FrankfurterAPI.Repositorios
{
    public class RepositorioCurrency : IRepositorioCurrency
    {
        private readonly ApplicationDbContext context;

        public RepositorioCurrency(ApplicationDbContext context) {
            this.context = context;
        }

        public async Task ActualizarCurrency(Currency currency)
        {
            context.Update(currency);
            await context.SaveChangesAsync();
        }

        public async Task BorrarCurrency(int Id)
        {
            await context.Currency.Where(x => x.Id == Id).ExecuteDeleteAsync();
        }

        public async Task<int> Crear(Currency currency)
        {
            context.Add(currency);
            await context.SaveChangesAsync();
            return currency.Id;
        }

        public async Task Cargar(Currency currency)
        {
            context.Add(currency);
            await context.SaveChangesAsync();
   
        }

        public async Task<bool> Existe(string symbol)
        {
            return await context.Currency.AnyAsync(x => x.NameSymbol == symbol);
        }

        public async Task<bool> ExisteId(int Id)
        {
            return await context.Currency.AnyAsync(x => x.Id == Id);
        }

        public async Task<bool> ExisteName(string name)
        { 
            return await context.Currency.AnyAsync(x => x.Name == name);
        }


        public async Task<List<Currency>> ListadoDeCurrency()
        {
            return await context.Currency.ToListAsync();
        }

        public async Task<Currency?> ListarCurrency(int Id)
        {
            return await context.Currency.FirstOrDefaultAsync(x => x.Id == Id);
        }

    }
}
