﻿using FrankfurterAPI.Entidades;

namespace FrankfurterAPI.Repositorios
{
    public interface IRepositorioCurrency
    {
        Task<int> Crear(Currency currency);
        Task<List<Currency>> ListadoDeCurrency();
        Task<Currency?> ListarCurrency(int Id);
        Task<bool> Existe(string symbol);
        Task<bool> ExisteId(int Id);
        Task<bool> ExisteName(string name);
        Task ActualizarCurrency(Currency currency);
        Task BorrarCurrency(int Id);
        Task Cargar(Currency currency);

    }
}
