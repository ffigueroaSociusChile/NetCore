﻿namespace FrankfurterAPI.DTOs
{
    public class CrearCurrencyDto
    {
        public string nameSymbol { get; set; } = null!;
        public string name { get; set; } = null!;
    }
}
