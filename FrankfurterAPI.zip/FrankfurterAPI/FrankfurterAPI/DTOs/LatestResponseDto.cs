﻿using System.Text.Json.Serialization;

namespace FrankfurterAPI.DTOs
{
    public class LatestResponseDto
    {
        [JsonPropertyName("amount")]
        public decimal? amount { get; set; }
        [JsonPropertyName("base")]
        public string? Base { get; set; }
        public DateTime Date { get; set; }
        [JsonPropertyName("rates")]
        public Dictionary<string, decimal> Rates { get; set; } = null!;
    }

}
