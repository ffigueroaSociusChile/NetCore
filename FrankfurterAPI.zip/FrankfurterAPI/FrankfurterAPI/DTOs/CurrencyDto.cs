﻿using System.ComponentModel.DataAnnotations;

namespace FrankfurterAPI.DTOs
{
    public class CurrencyDto
    {
        public int Id { get; set; }
        public string NameSymbol { get; set; } = null!;
        public string Name { get; set; } = null!;
    }
}
