﻿namespace FrankfurterAPI.DTOs
{
    public class ActualizaCurrencyDto
    {
        public string nameSymbol { get; set; } = null!;
        public string name { get; set; } = null!;
    }
}
